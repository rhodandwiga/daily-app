package com.example.daily;
import android.accessibilityservice.AccessibilityServiceInfo;

import android.app.AppOpsManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityManager;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Check permissions
        if (!hasUsageAccess()) {
            Toast.makeText(this, "Please enable Usage Access for Daily Pulse", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));
        }

        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Please enable Overlay Permission for app blocking", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION));
        }

        if (!isAccessibilityServiceEnabled(this, AppBlockerService.class)) {
            Toast.makeText(this, "Please enable Accessibility Service for Daily Pulse", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        }

        // Start Installed Apps Activity
        startActivity(new Intent(this, InstalledAppsActivity.class));

        // Start monitoring app usage
        AppUsageService appUsageService = new AppUsageService(this);
        appUsageService.startMonitoring();
    }

    private boolean hasUsageAccess() {
        try {
            AppOpsManager appOps = (AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);
            int mode = appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
                    android.os.Process.myUid(), getPackageName());
            return mode == AppOpsManager.MODE_ALLOWED;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean isAccessibilityServiceEnabled(Context context, Class<? extends AccessibilityService> service) {
        AccessibilityManager am = (AccessibilityManager) context.getSystemService(Context.ACCESSIBILITY_SERVICE);
        List<AccessibilityServiceInfo> enabledServices = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_GENERIC);

        for (AccessibilityServiceInfo info : enabledServices) {
            ComponentName componentName = ComponentName.unflattenFromString(info.getId());
            if (componentName != null && componentName.getClassName().equals(service.getName())) {
                return true;
            }
        }
        return false;
    }
}
