package com.example.daily;

import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AppListAdapter extends RecyclerView.Adapter<AppListAdapter.ViewHolder> {
    private Context context;
    private List<AppInfo> appList;
    private SharedPreferences preferences;

    public AppListAdapter(Context context, List<AppInfo> appList) {
        this.context = context;
        this.appList = appList;
        this.preferences = context.getSharedPreferences("AppLimits", Context.MODE_PRIVATE);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_app, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        AppInfo app = appList.get(position);
        holder.appName.setText(app.getAppName());
        holder.appIcon.setImageDrawable(app.getIcon());

        // Ensure we display valid usage time
        long usageTime = app.getUsageTime();
        holder.appUsage.setText("Usage: " + usageTime + " min");

        // Get saved limit
        SharedPreferences prefs = context.getSharedPreferences("AppLimits", Context.MODE_PRIVATE);
        int limit = prefs.getInt(app.getPackageName(), 0);
        holder.appLimit.setText("Limit: " + (limit > 0 ? limit + " min" : "No Limit"));

        // Open limit setting dialog when clicking on the button
        holder.setLimitButton.setOnClickListener(v -> showTimeLimitDialog(app.getPackageName()));
    }


    @Override
    public int getItemCount() {
        return appList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView appName, appUsage, appLimit;
        ImageView appIcon;
        Button setLimitButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            appName = itemView.findViewById(R.id.app_name);
            appIcon = itemView.findViewById(R.id.app_icon);
            appUsage = itemView.findViewById(R.id.app_usage);
            appLimit = itemView.findViewById(R.id.app_limit);
            setLimitButton = itemView.findViewById(R.id.set_limit_button);
        }
    }

    private void showTimeLimitDialog(String packageName) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Set Time Limit (minutes)");

        final EditText input = new EditText(context);
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        builder.setView(input);

        builder.setPositiveButton("Set", (dialog, which) -> {
            String value = input.getText().toString();
            if (!value.isEmpty()) {
                int minutes = Integer.parseInt(value);
                saveAppLimit(packageName, minutes);
                Toast.makeText(context, "Time limit set for " + minutes + " minutes", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }

    private void saveAppLimit(String packageName, int minutes) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt(packageName, minutes);
        editor.apply();
    }
}