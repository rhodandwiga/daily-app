package com.example.daily;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;

import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import java.util.HashSet;
import java.util.List;

public class AppBlockerService extends AccessibilityService {
    public static HashSet<String> blockedApps = new HashSet<>();

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            String packageName = event.getPackageName().toString();

            if (shouldBlockApp(packageName)) {
                Log.d("AppBlockerService", "Blocking app: " + packageName);
                sendToHomeScreen();
            }
        }
    }

    private boolean shouldBlockApp(String packageName) {
        SharedPreferences preferences = getSharedPreferences("AppLimits", Context.MODE_PRIVATE);
        int limit = preferences.getInt(packageName, 0); // Get limit in minutes

        if (limit > 0) {
            long usageTime = getAppUsageTime(packageName);
            return usageTime >= (limit * 60 * 1000); // Convert minutes to milliseconds
        }
        return false;
    }

    private long getAppUsageTime(String packageName) {
        UsageStatsManager usageStatsManager = (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);
        long currentTime = System.currentTimeMillis();
        long startTime = currentTime - 1000 * 60 * 60 * 24; // Last 24 hours

        List<UsageStats> stats = usageStatsManager.queryUsageStats(
                UsageStatsManager.INTERVAL_DAILY, startTime, currentTime);

        for (UsageStats usageStats : stats) {
            if (usageStats.getPackageName().equals(packageName)) {
                return usageStats.getTotalTimeInForeground();
            }
        }
        return 0;
    }

    private void sendToHomeScreen() {
        Intent homeIntent = new Intent(Intent.ACTION_MAIN);
        homeIntent.addCategory(Intent.CATEGORY_HOME);
        homeIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(homeIntent);
    }

    @Override
    public void onInterrupt() {
        Log.d("AppBlockerService", "Accessibility Service Interrupted");
    }
}
